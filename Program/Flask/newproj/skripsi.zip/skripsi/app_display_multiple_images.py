import glob
import os
import numpy as np
from numpy import genfromtxt
from skimage import io, segmentation, color
import matplotlib.pyplot as plt
from skimage.future import graph
import networkx as nx
from networkx.algorithms import isomorphism
from flask import Flask, request, render_template, send_from_directory
import StringIO
import base64

__author__ = 'wijaya'

app = Flask(__name__)



APP_ROOT = os.path.dirname(os.path.abspath(__file__))

@app.route("/")
def index():
    return render_template("input.html")

@app.route("/input", methods=["POST"])
def upload():

    # target = os.path.join(APP_ROOT, 'images/')
    # print(target)
    # if not os.path.isdir(target):
    #         os.mkdir(target)
    # else:
    #     print("Couldn't create upload directory: {}".format(target))
    # print(request.files.getlist("file"))
    if request.method == 'POST':
        if request.form['submit'] == 'Segmentation':
            for upload in request.files.getlist("file"):
                print(upload)
                print("{} is the file name".format(upload.filename))
                filename = upload.filename

            
            filename = filename.encode('utf-8')
            filename = 'static/{}'.format(filename)
            print(filename)
            print(type(filename))
            img = io.imread(filename)
            label = segmentation.felzenszwalb(img, min_size=340 )
            out = color.label2rgb(label, img, kind='overlay')
            sg = 'segmen.png'
            pelot = StringIO.StringIO()
            plotku = plt.imshow(out)
            plt.savefig(pelot, format='png')
            pelot.seek(0)
            plot_url = base64.b64encode(pelot.getvalue())
            return render_template("segmentation.html", labels = label, plot_url = plot_url)

        else:
            for upload in request.files.getlist("file"):
                print(upload)
                print("{} is the file name".format(upload.filename))
                filename = upload.filename

            print(filename)
            filename = filename.encode('utf-8')
            filename = 'static/{}'.format(filename)
            print(filename)
            print(type(filename))
            path1 = 'images/'
            path2 = 'graph/'
            imgFile = []
            graphFile = []


            for filename1 in glob.glob(os.path.join(path1, '*.jpg')):
                imgFile.append(filename1)

            for filename2 in glob.glob(os.path.join(path2, '*.gpickle')):
                graphFile.append(filename2)

            matchedList = []
            img = io.imread(filename)
            label = segmentation.felzenszwalb(img, min_size=340 )
            print(label)
            g1 = graph.rag_mean_color(img, label, connectivity=2, mode='distance')
            print(type(g1))
            for i in range(0,len(graphFile)):
                g2 = nx.read_gpickle(graphFile[i])
                gm = isomorphism.GraphMatcher(g1,g2)
                if(gm.is_isomorphic()):
                    matchedList.append(imgFile[i])

            print(type(matchedList[0]))

            newList = []
            for i in range(len(matchedList)):
                fl = matchedList[i].replace("images\\","")
                newList.append(fl)

            n = len(newList)
            return render_template("gallery.html", image_names=newList, jumlah=n)

@app.route('/upload/<filename>')
def send_image(filename):
    return send_from_directory("images", filename)

@app.route('/gallery')
def get_gallery():
    image_names = ['img001.jpg','img050.jpg']
    n = len(image_names)
    print(image_names)
    return render_template("gallery.html", image_names=image_names, jumlah=n)

if __name__ == "__main__":
    app.run(port=4555, debug=True)